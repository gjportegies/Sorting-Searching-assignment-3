/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author thimovanleeuwen
 */
public class RegEx {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
       
        Pattern p = Pattern.compile(""
                + "([+]316|00316|06)(-)?[1-9][0-9]{7}|" //het checken voor een mobiel nummer
                + "([+]31|0031|0)[1-9]{2}[0-9](-)?[1-9][0-9]{6}|" // het checken voor een nummer met een 4-cijferig net nummer
                + "([+]31|0031|0)[1-9][0-9](-)?[1-9][0-9]{6}|"  // het checken voor een nummer met een 3-cijferig net nummer
                + "112|" // het checken van het noodnummer
                + "0900(-)?[0-9]{4}|" //  het checken van 0900-XXXX nummers
                + "0800(-)?[0-9]{4}"); //  het checken van 0800-XXXX nummers
        
        Matcher m = p.matcher("00006372893");
        boolean b = m.matches();
        System.out.println(b);
        
  
    }
  
    
    
    
  
    
    
    
    
}
